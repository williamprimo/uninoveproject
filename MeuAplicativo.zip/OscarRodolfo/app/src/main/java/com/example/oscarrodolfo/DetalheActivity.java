package com.example.oscarrodolfo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DetalheActivity extends AppCompatActivity {

    TextView titulo, genero , resumo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhe);


        titulo = findViewById(R.id.titulo);
        genero = findViewById(R.id.genero);
        resumo = findViewById(R.id.resumo);

        Bundle dados = getIntent().getExtras();

    switch (dados.getInt("id")){

        case R.id.br:
            titulo.setText(R.string.titulo_br);
            genero.setText(R.string.genero_br);
            resumo.setText(R.string.resumo_br);
            break;
    }
    }
}
