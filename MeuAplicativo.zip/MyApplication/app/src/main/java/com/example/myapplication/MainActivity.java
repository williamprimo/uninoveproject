package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    TextView numero,zerar;
    Integer valor = 0;
    Integer i = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numero = findViewById(R.id.numero);

    }



    public void contar(View view){
        valor = valor + 1;
        numero.setText(Integer.toString(valor));
      if (valor == i+1){

          Toast.makeText(this, "Você chegou no seu último número do RA", Toast.LENGTH_SHORT).show();
      }
        }



    public void zerar (View view){
        valor = 0;
        numero.setText(Integer.toString(valor));
    }
}
